package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class display extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);
        String username = getIntent().getStringExtra("Username");
        TextView tv= (TextView)findViewById(R.id.TVusername);
        tv.setText(username);

         String password= getIntent().getStringExtra("Password");
         TextView tv1 = (TextView)findViewById(R.id.TVpassword);
         tv1.setText(password);
}
}
